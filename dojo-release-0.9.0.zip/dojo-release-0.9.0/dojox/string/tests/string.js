if(!dojo._hasResource["dojox.string.tests.string"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojox.string.tests.string"] = true;
dojo.provide("dojox.string.tests.string");

try{
	dojo.require("dojox.string.tests.Builder");
} catch(e){ }

}
