if(!dojo._hasResource["dojox.presentation"]){ //_hasResource checks added by build. Do not use _hasResource directly in your code.
dojo._hasResource["dojox.presentation"] = true;
dojo.provide("dojox.presentation");
dojo.require("dojox.presentation._base"); 

}
