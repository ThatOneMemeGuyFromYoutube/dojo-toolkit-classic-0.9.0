dojo.provide("dijit.tests.Container");

if(dojo.isBrowser){
	doh.registerUrl("dijit.tests.Container", dojo.moduleUrl("dijit", "tests/Container.html"));
}
