dojo.provide("dijit.tests.layout.ContentPane");

if(dojo.isBrowser){
	doh.registerUrl("dijit.tests.layout.ContentPane", dojo.moduleUrl("dijit", "tests/layout/ContentPane.html"), 30000);
}
