({
		invalidMessage: "* Il valore inserito non è valido.",
		missingMessage: "* Questo valore è obbligatorio.",
		rangeMessage: "* Questo valore è al di fuori dell'intervallo consentito"
})
