dojo.require("dojox._sql.common");
dojo.provide("dojox.sql");
