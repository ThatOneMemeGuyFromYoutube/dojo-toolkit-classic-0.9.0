dojo.provide("dojox.string.tests.string");

try{
	dojo.require("dojox.string.tests.Builder");
} catch(e){ }
