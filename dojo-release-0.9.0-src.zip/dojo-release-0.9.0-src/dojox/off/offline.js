dojo.provide("dojox.off.offline");

dojo.require("dojox.storage");
dojo.require("dojox.sql");
dojo.require("dojox.off");
dojo.require("dojox.off.sync");
dojo.require("dojox.off.ui");
