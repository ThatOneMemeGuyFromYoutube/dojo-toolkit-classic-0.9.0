dojo.provide("dojox.collections");
dojo.require("dojox.collections._base");
