if(this["dojo"]){
	dojo.provide("doh._rhinoRunner");
}

doh.debug = print;
