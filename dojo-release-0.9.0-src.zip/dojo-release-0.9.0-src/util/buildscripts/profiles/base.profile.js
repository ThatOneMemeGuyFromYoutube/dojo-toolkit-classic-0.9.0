//To build just Dojo base, you just need an empty file.
